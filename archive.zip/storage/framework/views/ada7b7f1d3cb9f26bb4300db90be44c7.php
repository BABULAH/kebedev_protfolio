<h2><?php echo e($subject_mail); ?></h2>
<h3>Contact from: <?php echo e($name); ?></h3>
<h3>Contact from: <?php echo e($email); ?></h3>
<div><?php echo e($content); ?></div><?php /**PATH C:\Users\BABULAH\Desktop\LARAVEL\MesVacances\Portfolio-main\resources\views/mail/contactmail.blade.php ENDPATH**/ ?>