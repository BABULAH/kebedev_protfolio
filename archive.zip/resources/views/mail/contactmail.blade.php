<h2>{{ $subject_mail }}</h2>
<h3>Contact from: {{ $name }}</h3>
<h3>Contact from: {{ $email }}</h3>
<div>{{ $content }}</div>